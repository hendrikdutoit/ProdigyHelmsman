import re
import wsgiref.util
 
from webob.exc import HTTPMovedPermanently, HTTPSeeOther

from reahl.web.fw import ReahlWSGIApplication, Url


wrapped_application = ReahlWSGIApplication.from_directory('/home/IwanVoslooReahl/etc/reahl.d/reahlorg-5.1', start_on_first_request=True)

redirects = [(re.compile(from_url), to_url, e) for from_url, to_url, e in [
     (r'^/docs/current/(.*)$', '/docs/5.1/%s', HTTPSeeOther),
     (r'^/docs/2.1/current/(.*)$', '/docs/2.1/%s', HTTPMovedPermanently),
     (r'^(.*)tutorial/gettingstarted$', '%stutorial/gettingstarted.d.html', HTTPMovedPermanently),
     (r'^(.*)tutorial/gettingstarted-install$', '%stutorial/gettingstarted-install.d.html', HTTPMovedPermanently),
     (r'^/wfmwiki(.*)$', '/?#%s', HTTPMovedPermanently),
     (r'^/af/((?!i18nexample/.*).*)$', '/%s', HTTPMovedPermanently)
     ]]

def application(environ, start_response):
    request_uri = Url(wsgiref.util.request_uri(environ, include_query=True))
    for from_regex, to_url, exception in redirects:
        match = re.match(from_regex, request_uri.path)
        if match:
            request_uri.path = to_url % match.group(1)
            return exception(location=str(request_uri))(environ, start_response)

    if request_uri.path.startswith('/project'):
        query_dict = request_uri.get_query_dict()
        if query_dict['name'] == ['stubble']:
            request_uri.path = '/docs/5.1/stubble/index.d.html'
            return HTTPMovedPermanently(location=str(request_uri))(environ, start_response)
        elif query_dict['name'] == ['tofu']:
            request_uri.path = '/docs/5.1/tofu/index.d.html'
            return HTTPMovedPermanently(location=str(request_uri))(environ, start_response)
        elif query_dict['name'] == ['tut']:
            request_uri.path = '/docs/5.1/tofu/index.d.html'
            return HTTPMovedPermanently(location=str(request_uri))(environ, start_response)

    return wrapped_application(environ, start_response)
